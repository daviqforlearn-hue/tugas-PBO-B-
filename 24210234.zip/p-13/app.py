# Python 3.x + Flask + Flask-Login
from flask import Flask, render_template, request, redirect, url_for, abort
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from functools import wraps

app = Flask(__name__)
app.secret_key = "secret-key-demo"

# ==================================
# Flask Login Setup
# ==================================
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# ==================================
# Dummy User Data (Spasi berlebih sudah dibersihkan)
# ==================================
USERS = {
    "admin": {"password": "admin123", "role": "admin"},
    "editor": {"password": "editor123", "role": "editor"}, # Soal 4: Tambah role editor
    "user": {"password": "user123", "role": "user"}
}

# ==================================
# User Class (Fix: __init__)
# ==================================
class User(UserMixin):
    def __init__(self, username, role):
        self.id = username
        self.role = role

# ==================================
# Load User
# ==================================
@login_manager.user_loader
def load_user(user_id):
    if user_id in USERS:
        return User(user_id, USERS[user_id]["role"])
    return None

# ==================================
# Soal 4: Reusable Role Checker Decorator
# ==================================
def role_required(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.role not in allowed_roles:
                abort(403) # Trigger custom 403 handler
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ==================================
# Routes
# ==================================
@app.route("/")
def home():
    return redirect("/login")

# Soal 1: Fitur Registrasi
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not username or not password:
            return render_template("register.html", error="Username dan password wajib diisi.")
        
        if password != confirm_password:
            return render_template("register.html", error="Password dan konfirmasi password tidak cocok.")
        
        if username in USERS:
            return render_template("register.html", error="Username sudah digunakan.")

        # Simpan ke dictionary USERS dengan default role 'user'
        USERS[username] = {"password": password, "role": "user"}
        return redirect(url_for("login", success="Registrasi berhasil! Silakan login."))

    return render_template("register.html")

# Soal 2: Login dengan Pesan Error Spesifik
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if username not in USERS:
            return render_template("login.html", error="Username tidak ditemukan.")
        
        if USERS[username]["password"] != password:
            return render_template("login.html", error="Password yang dimasukkan salah.")

        user = User(username, USERS[username]["role"])
        login_user(user)
        return redirect("/dashboard")

    success_msg = request.args.get("success")
    return render_template("login.html", success=success_msg)

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=current_user.id, role=current_user.role)

@app.route("/admin")
@login_required
@role_required("admin") # Hanya admin
def admin():
    return render_template("admin.html")

# Soal 4: Halaman Editor
@app.route("/editor")
@login_required
@role_required("admin", "editor") # Admin dan Editor bisa akses
def editor():
    return render_template("editor.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect("/login")

# Soal 3: Custom 403 Forbidden Handler
@app.errorhandler(403)
def forbidden(error):
    return render_template("403.html"), 403

if __name__ == "__main__": # Fix: __name__
    app.run(debug=True)